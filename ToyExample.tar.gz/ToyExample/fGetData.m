function data = fGetData(file)

tb = readtable(file, 'Delimiter', ',', 'ReadVariableNames', true);
data = struct;

for i = 1 : size(tb.Properties.VariableNames, 2)
    header = tb.Properties.VariableNames{i};
    data.(header) = tb.(header);
end
