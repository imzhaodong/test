function pTick(md_file, input_file, output_file)

%% Input
data = fGetData(input_file);
in = struct;
in.currentDate = x2mdate(data.currentDate);
in.currentPos = data.currentPos;
in.livePrice = data.livePrice;

currentDate = datenum('July-3-2014');
% currentPos = 0;

%% Parameters
AUM = 100e6;
volTargetBp = 1;
volMin = 1e-3;

%% Load historical EOD data
data = fGetData(md_file);
asset = struct;
asset.Dates = x2mdate(data.Date);
asset.Prices = data.Rate;

%% Position calculation
asset.Vols = zeros(numel(asset.Dates), 1);
asset.Returns = [0; diff(asset.Prices)];
L = 9;
for iDate = L : numel(asset.Dates)
    asset.Vols(iDate) = sqrt(mean(asset.Returns(iDate-L+1:iDate).^2));
end
asset.Vols(1:L-1) = asset.Vols(L);
asset.Vols = max(asset.Vols, volMin);

idxDate = find(asset.Dates < in.currentDate, 1, 'last');
targetPos = round(AUM ./ asset.Vols(idxDate) * (volTargetBp*1e-4) / 1e5)*1e5;
targetPos = in.currentPos + (targetPos - in.currentPos);

%% Output
out = cell(2,4);
out(1,:) = {'Date', 'livePrice', 'currentPos', 'targetPos'};
out{2,1} = m2xdate(in.currentDate);
out{2,2} = in.livePrice;
out{2,3} = in.currentPos;
out{2,4} = targetPos;
targetPos;
cell2csv(output_file, out);

fprintf('Date %s, livePrice=%.2f, currentPos=%d, targetPos=%d \n', datestr(in.currentDate), in.livePrice, in.currentPos, targetPos);
